<?php
	if(isset($_POST['SSC']) && isset($_POST['HSC']) && isset($_POST['BSc']) && isset($_POST['MSc']))
	{
		echo $_POST['SSC'];
		echo " , ";
		echo $_POST['HSC'];
		echo " , ";
		echo $_POST['BSc'];
		echo " , ";
		echo $_POST['MSc'];
	}

	elseif(isset($_POST['SSC']) && (isset($_POST['HSC'])) && (isset($_POST['BSc'])))
	{
		echo $_POST['SSC'];
		echo " , ";
		echo $_POST['HSC'];
		echo " , ";
		echo $_POST['BSc'];
	}
	
	elseif(isset($_POST['SSC']) && isset($_POST['HSC']))
	{
			echo $_POST['SSC'];
			echo " , ";
			echo $_POST['HSC'];	
	}
	
	elseif(isset($_POST['SSC']) || isset($_POST['HSC']) || isset($_POST['BSc']) || isset($_POST['MSc']))
	{
		echo "Must select at least two.";
	}	
?>
<form action = "#" method = "POST">
	<fieldset>
		<legend>DEGREE</legend>
			
			<input type = "checkbox" name = "SSC" value = "SSC">SSC
			<input type = "checkbox" name = "HSC" value = "HSC">HSC
			<input type = "checkbox" name = "BSC" value = "BSc">BSc
			<input type = "checkbox" name = "MSC" value = "MSc">MSc
			
			<br></br>
			<input type = "submit" name = "submit" value = "submit">
			<hr/>
			
			
	</fieldset>
</form>	