<?php

	if(isset($_POST['group']))
	{
		if($_POST['group'])
		{
			echo $_POST['group'];
		}
		elseif($_POST['group']=='')
		{
			echo "Must select blood group!";
		}
	}
?>
<form action="#" method="POST">
	<fieldset>
		<legend>BLOOD GROUP</legend>
			
			<select name = "group">
				<option value = ""></option>
				<option value = "Apos">Apos</option>
				<option value = "Aneg">Aneg</option>
				<option value = "Bpos">Bpos</option>
				<option value = "Bneg">Bneg</option>
				<option value = "ABpos">ABpos</option>
				<option value = "ABneg">ABneg</option>
				<option value = "Opos">Opos</option>
				<option value = "Oneg">Oneg</option>
			</select>
			
			<br></br>
			<input type = "submit" name = "submit" value = "submit">
			<hr/>
	</fieldset>
</form>	