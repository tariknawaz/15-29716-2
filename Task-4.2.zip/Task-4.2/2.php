<?php
	
	if(isset($_POST['email']) == true && empty($_POST['email']) == false)
	{	
		$email = $_POST['email'];
		if(filter_var($email,FILTER_VALIDATE_EMAIL) == true)
		{
			echo $_POST['email'];			
		}
		else
		{
			echo "Not a valid email address";
		}	
	}
	if(isset($_POST['email']))
	{
		if($_POST['email']=='')
		{
			echo "Cannot be empty";
		}
	}
?>

<form action="#" method="POST">
	<fieldset>
		<legend>Email</legend>
		<input type="text" name="email" value="">i<br/><br/>
		<input type="submit" name="submit" value="Submit">
		<hr/>
	</fieldset>
</form>