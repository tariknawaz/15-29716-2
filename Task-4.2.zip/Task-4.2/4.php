<?php
	
	if(isset($_POST['gender']))
	{
		echo $_POST['gender'];
	}	
	else	
	{
		echo "Not valid!";		
	}
?>
<form action="#" method="POST">
	<fieldset>
		<legend>GENDER</legend>
			
			<input type="radio" name="gender" value="male">Male
			<input type="radio" name="gender" value="female">Female
			<input type="radio" name="gender" value="other">Other
  
		<br></br>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>