<?php

	if(isset($_POST['SSC']))
	{ echo $_POST['SSC'];}

	if(isset($_POST['HSC']))
	{ echo $_POST['HSC'];}

	if(isset($_POST['BSC']))
	{ echo $_POST['BSC'];}

	if(isset($_POST['MSC']))
	{ echo $_POST['MSC'];}

?>