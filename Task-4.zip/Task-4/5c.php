<?php error_reporting(0);?>

<form action = "#" method = "POST">
	<fieldset>
		<legend>DEGREE</legend>
			
			<input type = "checkbox" name = "SSC" value = "SSC" 
			<?php if($_POST['SSC'] == "SSC"){ echo "checked"];}?>>SSC</input>
			<input type = "checkbox" name = "HSC" value = "HSC" 
			<?php if($_POST['HSC'] == "HSC"){ echo "checked";}?>>HSC</input>
			<input type = "checkbox" name = "BSC" value = "BSC" 
			<?php if($_POST['BSC'] == "BSC"){ echo "checked";}?>>BSC</input>
			<input type = "checkbox" name = "MSC" value = "MSC" 
			<?php if($_POST['MSC'] == "MSC"){ echo "checked";}?>>MSC</input>
			
			<br></br>
			<input type = "submit" name = "submit" value = "submit">
			<hr/>
			
			
	</fieldset>
</form>