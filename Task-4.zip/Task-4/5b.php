<?php

	if(isset($_POST['SSC']))
	{ echo $_POST['SSC'];}

	if(isset($_POST['HSC']))
	{ echo $_POST['HSC'];}

	if(isset($_POST['BSC']))
	{ echo $_POST['BSC'];}

	if(isset($_POST['MSC']))
	{ echo $_POST['MSC'];}

?>
<form action = "#" method = "POST">
	<fieldset>
		<legend>DEGREE</legend>
			
			<input type = "checkbox" name = "SSC" value = "SSC">SSC
			<input type = "checkbox" name = "HSC" value = "HSC">HSC
			<input type = "checkbox" name = "BSC" value = "BSC">BSC
			<input type = "checkbox" name = "MSC" value = "MSC">MSC
			
			<br></br>
			<input type = "submit" name = "submit" value = "submit">
			<hr/>
			
			
	</fieldset>
</form>	