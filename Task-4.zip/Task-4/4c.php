<?php error_reporting(0);?>

<form action="#" method="POST">
	<fieldset>
		<legend>GENDER</legend>
			
			<input type="radio" name="gender" value="male" 
			<?php if($_POST['gender'] == "male"){ echo "checked";} ?>>male</input>
			<input type="radio" name="gender" value="female" 
			<?php if($_POST['gender'] == "female"){ echo "checked";} ?>>female</input>
			<input type="radio" name="gender" value="other" 
			<?php if($_POST['gender'] == "other"){ echo "checked";} ?>>other</input>
  
		<br></br>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>