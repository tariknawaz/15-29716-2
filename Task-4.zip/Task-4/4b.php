<?php
	
	if(isset($_POST['male'])){
		echo $_POST['male'];
	}
	
	if(isset($_POST['female'])){
		echo $_POST['female'];
	}
	
	if(isset($_POST['other'])){
		echo $_POST['other'];
	}
?>
<form action="#" method="POST">
	<fieldset>
		<legend>GENDER</legend>
			
			<input type="radio" name="male" value="male">Male
			<input type="radio" name="female" value="female">Female
			<input type="radio" name="other" value="other">Other
  
		<br></br>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>